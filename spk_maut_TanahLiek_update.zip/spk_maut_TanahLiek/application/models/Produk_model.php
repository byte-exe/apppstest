<?php
    
    defined('BASEPATH') OR exit('No direct script access allowed');
    
    class Produk_model extends CI_Model {

        public function tampil()
        {
            $query = $this->db->get('produk');
            return $query->result();
        }

        public function getTotal()
        {
            return $this->db->count_all('produk');
        }

        public function insert($data = [])
        {
            $result = $this->db->insert('produk', $data);
            return $result;
        }

        public function show($id_produk)
        {
            $this->db->where('id_produk', $id_produk);
            $query = $this->db->get('produk');
            return $query->row();
        }

        public function update($id_produk, $data = [])
        {
            $ubah = array(
                'nama'  => $data['nama'],
                'harga'  => $data['harga']
            );

            $this->db->where('id_produk', $id_produk);
            $this->db->update('produk', $ubah);
        }


        public function delete($id_produk)
        {
            $this->db->where('id_produk', $id_produk);
            $this->db->delete('produk');
        }
    }
    
    