<?php
    
    defined('BASEPATH') OR exit('No direct script access allowed');
    
    class Produk extends CI_Controller {
    
        public function __construct()
        {
            parent::__construct();
            $this->load->library('pagination');
            $this->load->library('form_validation');
            $this->load->model('Produk_model');

            if ($this->session->userdata('id_user_level') != "1") {
            ?>
				<script type="text/javascript">
                    alert('Anda tidak berhak mengakses halaman ini!');
                    window.location='<?php echo base_url("Login/home"); ?>'
                </script>
            <?php
			}
        }

        public function index()
        {
			$data = [
                'page' => "Produk",
				'list' => $this->Produk_model->tampil(),
                
            ];
            $this->load->view('produk/index', $data);
        }
        
        //menampilkan view create
        public function create()
        {
            $data['page'] = "Produk";
            $this->load->view('produk/create',$data);
        }

        //menambahkan data ke database
        public function store()
        {
                $data = [
                    'nama' => $this->input->post('nama'),
                    'harga' => $this->input->post('harga'),
                    
                ];
                
                // $this->form_validation->set_rules('keterangan', 'Keterangan', 'required');
                
                $this->form_validation->set_rules('harga', 'harga', 'required'); 
				$this->form_validation->set_rules('nama', 'Nama', 'required'); 
    
                if ($this->form_validation->run() != false) {
                    $result = $this->Produk_model->insert($data);
                    if ($result) {
                        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil disimpan!</div>');
						redirect('produk');
                    }
                } else {
                    $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data gagal disimpan!</div>');
                    redirect('produk/create');
                    
                }
        }

        public function edit($id_produk)
        {
            $produk = $this->Produk_model->show($id_produk);
            $data = [
                'page' => "Produk",
				'produk' => $produk
            ];
            $this->load->view('produk/edit', $data);
        }
		
		public function detail($id_produk)
        {
            $produk = $this->Produk_model->show($id_produk);
            $data = [
                'page' => "Produk",
				'produk' => $produk
            ];
            $this->load->view('produk/detail', $data);
        }
    
        public function update($id_produk)
        {
            $id_alternatif = $this->input->post('id_produk');
            $data = array(
                'nama' => $this->input->post('nama'),
                'harga' => $this->input->post('harga')
            );

            $this->Produk_model->update($id_produk, $data);
			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil diupdate!</div>');
            redirect('produk');
        }
    
        public function destroy($id_produk)
        {
            $this->Produk_model->delete($id_produk);
			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil dihapus!</div>');
            redirect('Produk');
        }

        public function filter_departemen () {
            $data['title'] = 'Data Mahasiswa';
        }
    
    }
    
    