<?php
    
    defined('BASEPATH') OR exit('No direct script access allowed');
    
    class Alternatif extends CI_Controller {
    
        public function __construct()
        {
            parent::__construct();
            $this->load->library('pagination');
            $this->load->library('form_validation');
            $this->load->model('Alternatif_model1');

            if ($this->session->userdata('id_user_level') != "1") {
            ?>
				<script type="text/javascript">
                    alert('Anda tidak berhak mengakses halaman ini!');
                    window.location='<?php echo base_url("Login/home"); ?>'
                </script>
            <?php
			}
        }

        public function index()
        {
			$data = [
                'page' => "Alternatif1",
				'list' => $this->Alternatif_model1->tampil(),
                
            ];
            $this->load->view('alternatif1/index', $data);
        }
        
        //menampilkan view create
        public function create()
        {
            $data['page'] = "Alternatif1";
            $this->load->view('alternatif1/create',$data);
        }

        //menambahkan data ke database
        public function store()
        {
                $data = [
                    'nama' => $this->input->post('nama'),
                    'keterangan' => $this->input->post('keterangan'),
                    'tgl_penilaian' => $this->input->post('tgl_penilaian'),
                    
                ];
                
                // $this->form_validation->set_rules('keterangan', 'Keterangan', 'required');
                $this->form_validation->set_rules('keterangan', 'keterangan', 'required');
                $this->form_validation->set_rules('tgl_penilaian', 'tgl_penilaian', 'required'); 
				$this->form_validation->set_rules('nama', 'Nama', 'required'); 
    
                if ($this->form_validation->run() != false) {
                    $result = $this->Alternatif_model->insert($data);
                    if ($result) {
                        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil disimpan!</div>');
						redirect('alternatif1');
                    }
                } else {
                    $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data gagal disimpan!</div>');
                    redirect('alternatif1/create');
                    
                }
        }

        public function edit($id_alternatif)
        {
            $alternatif = $this->Alternatif_model->show($id_alternatif);
            $data = [
                'page' => "Alternatif1",
				'alternatif' => $alternatif
            ];
            $this->load->view('alternatif1/edit', $data);
        }
		
		public function detail($id_alternatif)
        {
            $alternatif = $this->Alternatif_model->show($id_alternatif);
            $data = [
                'page' => "Alternatif1",
				'alternatif' => $alternatif
            ];
            $this->load->view('alternatif1/detail', $data);
        }
    
        public function update($id_alternatif)
        {
            $id_alternatif = $this->input->post('id_alternatif');
            $data = array(
                'nama' => $this->input->post('nama'),
                'keterangan' => $this->input->post('keterangan'),
                'tgl_penilaian' => $this->input->post('tgl_penilaian')
            );

            $this->Alternatif_model->update($id_alternatif, $data);
			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil diupdate!</div>');
            redirect('alternatif');
        }
    
        public function destroy($id_alternatif)
        {
            $this->Alternatif_model->delete($id_alternatif);
			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data berhasil dihapus!</div>');
            redirect('alternatif');
        }

        public function filter_departemen () {
            $data['title'] = 'Data Mahasiswa';
        }
    
    }
    
    