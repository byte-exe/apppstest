# Sistem Pendukung Keputusan Metode MAUT 
Sistem ini menggunakan framework codeigniter, dan metode maut itu sendiri merupakan suatu sistem informasi spesifik yang ditujukan untuk membantu manajemen dalam mengambil keputusan yang berkaitan dengan persoalan yang bersifat semi terstruktur.

<img width="100%" alt="Metode Maut" src="https://user-images.githubusercontent.com/81274723/213101778-27d6802a-a314-40c3-8586-451ba0d08f0c.png">

## Demo
Untuk melihat tampilan dari web bisa langsung klik link tersebut.
[Youtube](https://youtu.be/Zop5TjHbSXI)
